if (!self.define) {
  let e,
    s = {};
  const a = (a, c) => (
    (a = new URL(a + ".js", c).href),
    s[a] ||
      new Promise((s) => {
        if ("document" in self) {
          const e = document.createElement("script");
          (e.src = a), (e.onload = s), document.head.appendChild(e);
        } else (e = a), importScripts(a), s();
      }).then(() => {
        let e = s[a];
        if (!e) throw new Error(`Module ${a} didn’t register its module`);
        return e;
      })
  );
  self.define = (c, n) => {
    const i =
      e ||
      ("document" in self ? document.currentScript.src : "") ||
      location.href;
    if (s[i]) return;
    let r = {};
    const t = (e) => a(e, i),
      d = { module: { uri: i }, exports: r, require: t };
    s[i] = Promise.all(c.map((e) => d[e] || t(e))).then((e) => (n(...e), r));
  };
}
define(["./workbox-7c2a5a06"], function (e) {
  "use strict";
  importScripts("fallback-sGuuAyB7qvsj4VcSc0dtQ.js"),
    self.skipWaiting(),
    e.clientsClaim(),
    e.precacheAndRoute(
      [
        { url: "/404.svg", revision: "d38ac435783a21f1956e5ca6c207228d" },
        {
          url: "/_next/static/chunks/1260-372b3ea6abd45794.js",
          revision: "372b3ea6abd45794",
        },
        {
          url: "/_next/static/chunks/1545.6786c7972b807d99.js",
          revision: "6786c7972b807d99",
        },
        {
          url: "/_next/static/chunks/1763-c1390d48b980eea2.js",
          revision: "c1390d48b980eea2",
        },
        {
          url: "/_next/static/chunks/1b8dab7b-33a7d689b50bf9d0.js",
          revision: "33a7d689b50bf9d0",
        },
        {
          url: "/_next/static/chunks/228771e0-12c193089a199d71.js",
          revision: "12c193089a199d71",
        },
        {
          url: "/_next/static/chunks/31664189-867526fa299eb74a.js",
          revision: "867526fa299eb74a",
        },
        {
          url: "/_next/static/chunks/3201-bf8a8079f50bb3a1.js",
          revision: "bf8a8079f50bb3a1",
        },
        {
          url: "/_next/static/chunks/4359-0f68d4cb3b213c84.js",
          revision: "0f68d4cb3b213c84",
        },
        {
          url: "/_next/static/chunks/4546-e0e8aed9dbe60b4f.js",
          revision: "e0e8aed9dbe60b4f",
        },
        {
          url: "/_next/static/chunks/464.98a9dfbac2cbef70.js",
          revision: "98a9dfbac2cbef70",
        },
        {
          url: "/_next/static/chunks/5e2a4920-37045c8eaf30df23.js",
          revision: "37045c8eaf30df23",
        },
        {
          url: "/_next/static/chunks/65291039-3f7ec521be428e33.js",
          revision: "3f7ec521be428e33",
        },
        {
          url: "/_next/static/chunks/7017-53ac97a790173e7d.js",
          revision: "53ac97a790173e7d",
        },
        {
          url: "/_next/static/chunks/7151-0f6654a1c94da713.js",
          revision: "0f6654a1c94da713",
        },
        {
          url: "/_next/static/chunks/7518-1ed81ba098dfbb7e.js",
          revision: "1ed81ba098dfbb7e",
        },
        {
          url: "/_next/static/chunks/7656-40a33aff91166d3f.js",
          revision: "40a33aff91166d3f",
        },
        {
          url: "/_next/static/chunks/7779-87f9cd11d7ce218c.js",
          revision: "87f9cd11d7ce218c",
        },
        {
          url: "/_next/static/chunks/8511-23a299e530709ecb.js",
          revision: "23a299e530709ecb",
        },
        {
          url: "/_next/static/chunks/855-91e62d1fc3788d2d.js",
          revision: "91e62d1fc3788d2d",
        },
        {
          url: "/_next/static/chunks/8735-b39f553591334ec1.js",
          revision: "b39f553591334ec1",
        },
        {
          url: "/_next/static/chunks/9147-291f76f8e116579a.js",
          revision: "291f76f8e116579a",
        },
        {
          url: "/_next/static/chunks/ae51ba48-e56fab808b0cf0ff.js",
          revision: "e56fab808b0cf0ff",
        },
        {
          url: "/_next/static/chunks/c9184924-dfd66b27aaaedf86.js",
          revision: "dfd66b27aaaedf86",
        },
        {
          url: "/_next/static/chunks/framework-2a7024ed9d8eda31.js",
          revision: "2a7024ed9d8eda31",
        },
        {
          url: "/_next/static/chunks/main-2cfa152abc988d44.js",
          revision: "2cfa152abc988d44",
        },
        {
          url: "/_next/static/chunks/pages/404-6daa34e8f69f237c.js",
          revision: "6daa34e8f69f237c",
        },
        {
          url: "/_next/static/chunks/pages/_app-bc383ff311b5d9e2.js",
          revision: "bc383ff311b5d9e2",
        },
        {
          url: "/_next/static/chunks/pages/_error-e0eca0abcd0e9dd7.js",
          revision: "e0eca0abcd0e9dd7",
        },
        {
          url: "/_next/static/chunks/pages/_offline-7c135abb120de548.js",
          revision: "7c135abb120de548",
        },
        {
          url: "/_next/static/chunks/pages/about-us-e6cbbdac3102bdc4.js",
          revision: "e6cbbdac3102bdc4",
        },
        {
          url: "/_next/static/chunks/pages/auth/email-verification/%5Btoken%5D-16dfcaca38bd471b.js",
          revision: "16dfcaca38bd471b",
        },
        {
          url: "/_next/static/chunks/pages/auth/forget-password-c98938a7674b133b.js",
          revision: "c98938a7674b133b",
        },
        {
          url: "/_next/static/chunks/pages/auth/forget-password/%5Btoken%5D-b87c03bd5e029c00.js",
          revision: "b87c03bd5e029c00",
        },
        {
          url: "/_next/static/chunks/pages/auth/login-74f8e8f7a1301f7e.js",
          revision: "74f8e8f7a1301f7e",
        },
        {
          url: "/_next/static/chunks/pages/auth/phone-signup-82fa0f414292cd6d.js",
          revision: "82fa0f414292cd6d",
        },
        {
          url: "/_next/static/chunks/pages/auth/signup-61c22cb2d48e5ae6.js",
          revision: "61c22cb2d48e5ae6",
        },
        {
          url: "/_next/static/chunks/pages/checkout-d84be4dc81885aab.js",
          revision: "d84be4dc81885aab",
        },
        {
          url: "/_next/static/chunks/pages/contact-us-84ae03e4661b473f.js",
          revision: "84ae03e4661b473f",
        },
        {
          url: "/_next/static/chunks/pages/faq-c8bb1e11f8679bc0.js",
          revision: "c8bb1e11f8679bc0",
        },
        {
          url: "/_next/static/chunks/pages/index-4d135691c53e8afe.js",
          revision: "4d135691c53e8afe",
        },
        {
          url: "/_next/static/chunks/pages/offer-a67a77abb63de79c.js",
          revision: "a67a77abb63de79c",
        },
        {
          url: "/_next/static/chunks/pages/order/%5Bid%5D-014e90109c1e69db.js",
          revision: "014e90109c1e69db",
        },
        {
          url: "/_next/static/chunks/pages/privacy-policy-b642dc468c7bab76.js",
          revision: "b642dc468c7bab76",
        },
        {
          url: "/_next/static/chunks/pages/product/%5Bslug%5D-cde227206000daf2.js",
          revision: "cde227206000daf2",
        },
        {
          url: "/_next/static/chunks/pages/search-6bf9d9ec25cf058b.js",
          revision: "6bf9d9ec25cf058b",
        },
        {
          url: "/_next/static/chunks/pages/terms-and-conditions-c9c08c152b266ebe.js",
          revision: "c9c08c152b266ebe",
        },
        {
          url: "/_next/static/chunks/pages/user/add-shipping-address-3750ed7447514486.js",
          revision: "3750ed7447514486",
        },
        {
          url: "/_next/static/chunks/pages/user/change-password-420e59a4aa843ec7.js",
          revision: "420e59a4aa843ec7",
        },
        {
          url: "/_next/static/chunks/pages/user/dashboard-80291e134cd7e33a.js",
          revision: "80291e134cd7e33a",
        },
        {
          url: "/_next/static/chunks/pages/user/my-account-49335ee63cf7afb9.js",
          revision: "49335ee63cf7afb9",
        },
        {
          url: "/_next/static/chunks/pages/user/my-orders-ad204355ff23d67a.js",
          revision: "ad204355ff23d67a",
        },
        {
          url: "/_next/static/chunks/pages/user/recent-order-3f232ecb47aadf2b.js",
          revision: "3f232ecb47aadf2b",
        },
        {
          url: "/_next/static/chunks/pages/user/update-profile-aefb18def4db9deb.js",
          revision: "aefb18def4db9deb",
        },
        {
          url: "/_next/static/chunks/polyfills-42372ed130431b0a.js",
          revision: "846118c33b2c0e922d7b3a7676f81f6f",
        },
        {
          url: "/_next/static/chunks/webpack-9f428b477b24318c.js",
          revision: "9f428b477b24318c",
        },
        {
          url: "/_next/static/css/a90c3bb8df6bdbd1.css",
          revision: "a90c3bb8df6bdbd1",
        },
        {
          url: "/_next/static/css/bf081e41ff39e4ba.css",
          revision: "bf081e41ff39e4ba",
        },
        {
          url: "/_next/static/css/fe3ca4aa668b6f4f.css",
          revision: "fe3ca4aa668b6f4f",
        },
        {
          url: "/_next/static/sGuuAyB7qvsj4VcSc0dtQ/_buildManifest.js",
          revision: "4147ecc4c6142812a8e061d9e548f680",
        },
        {
          url: "/_next/static/sGuuAyB7qvsj4VcSc0dtQ/_ssgManifest.js",
          revision: "b6652df95db52feb4daf4eca35380933",
        },
        { url: "/_offline", revision: "sGuuAyB7qvsj4VcSc0dtQ" },
        {
          url: "/about-banner.jpg",
          revision: "79bcd14e1663eeb10fd2078a1b40a68a",
        },
        { url: "/about-us.jpg", revision: "a69c8f7c944c6dd9673e4e8407684ae9" },
        {
          url: "/app-download-img-left.png",
          revision: "72d8da82c11b9694f687e2b24711a82a",
        },
        {
          url: "/app-download-img.png",
          revision: "22ab424e74d09df11be0f6943a264856",
        },
        {
          url: "/app/app-store.svg",
          revision: "a717e97b14d37aa12c48a288bddf4bae",
        },
        {
          url: "/app/mastercard-icon.svg",
          revision: "2f3b7f6dc10d68bf74366ce0e4b39217",
        },
        {
          url: "/app/paypal-icon.svg",
          revision: "99025da84086629516e323641cdfd73b",
        },
        {
          url: "/app/play-store.svg",
          revision: "a2b0ad8b1000e23bf80ca9ef30b14b97",
        },
        {
          url: "/app/skrill-icon.svg",
          revision: "01cb261e1e28b74c3f51a379a63216d3",
        },
        {
          url: "/app/visa-icon.svg",
          revision: "58cb00fe42ab95ae26c5e7e429f04545",
        },
        { url: "/banner-1.jpg", revision: "96eaf5765f56f7574dc21db0424668f3" },
        { url: "/banner-2.jpg", revision: "d08fc088d9d75823e8259261e9208cf2" },
        {
          url: "/contact-us.png",
          revision: "1f0a34dcebe83884f7d986c29069cff0",
        },
        { url: "/cta-bg.png", revision: "0dd94ded00743cc74d0da8027b579b73" },
        {
          url: "/cta/cta-bg-1.jpg",
          revision: "45b3e432be8fc7f3eb09f2568a61d8c2",
        },
        {
          url: "/cta/cta-bg-2.jpg",
          revision: "83ca16fa37654fd7de5518d0f347a29c",
        },
        {
          url: "/cta/cta-bg-3.jpg",
          revision: "42c150e775ca1b35399b3428d5ee2e00",
        },
        {
          url: "/cta/delivery-boy.png",
          revision: "9914b651b1428467046e8b886166dac9",
        },
        {
          url: "/facebook-page.png",
          revision: "0a668853fee7423c27bb93b947a6fc1c",
        },
        { url: "/faq.svg", revision: "2979a7b97c0c5d96960e9558a389bbd4" },
        { url: "/favicon.png", revision: "0033e08ea1185a9ef4ddea787f470df5" },
        { url: "/flags/de.svg", revision: "a491da9c1549a36b293a6a391739dfda" },
        { url: "/flags/us.svg", revision: "8886b28b10e3ec0756a9935a216d5bba" },
        {
          url: "/icon-192x192.png",
          revision: "47e2812c3e78f1903ccd46f0545f5d48",
        },
        {
          url: "/icon-256x256.png",
          revision: "5cfadd2f4679b3d86f1d994297809226",
        },
        {
          url: "/icon-384x384.png",
          revision: "e793bffd9497800be7d461caa873b96b",
        },
        {
          url: "/icon-512x512.png",
          revision: "b9df59369ad910b5d3e338e9076fd944",
        },
        {
          url: "/kachabazar-store-min.png",
          revision: "6bf12cd3f0a8d7ccf8285ea0672bf182",
        },
        {
          url: "/loader/spinner.gif",
          revision: "9317b1364997865cda53478fb9302977",
        },
        {
          url: "/logo/bag-shoping.svg",
          revision: "54014870b794b613e62017decbe943d0",
        },
        {
          url: "/logo/kachabazar-color-1024x1024.png",
          revision: "ce175e368a7e32f8a8d09a528924d542",
        },
        {
          url: "/logo/kachabazar-light-1024x1024.png",
          revision: "642bf695a41f2b91f2ef0a1c6c4289a0",
        },
        {
          url: "/logo/logo-color.png",
          revision: "5935965ef93ee2a9eab4a1240699bc5f",
        },
        {
          url: "/logo/logo-color.svg",
          revision: "9cdfd2a1723ebe5d6fbfeb2a3a07765d",
        },
        {
          url: "/logo/logo-dark-2.svg",
          revision: "990e13afb1b79734e26b71f2fcc062d9",
        },
        {
          url: "/logo/logo-dark.svg",
          revision: "3d5619a9dd2312d20ee908259e95a635",
        },
        {
          url: "/logo/logo-light-2.svg",
          revision: "8e9e97fd3acd9a7aa3525e2c5eb93811",
        },
        {
          url: "/logo/logo-light.svg",
          revision: "a295f016c697789c084b023006b33ac5",
        },
        { url: "/manifest.json", revision: "1bdc898597594f46bcd9b0ae76e7c991" },
        { url: "/no-result.svg", revision: "508b2439b4b83ce579e826c9c625b675" },
        {
          url: "/page-header-bg.jpg",
          revision: "c7cf9224e6c1ae3add73d30c2ae7a8f8",
        },
        {
          url: "/payment-method/payment-logo.png",
          revision: "469911779f6463e5751cf5b7046384d2",
        },
        { url: "/robots.txt", revision: "61c27d2cd39a713f7829422c3d9edcc7" },
        {
          url: "/slider/slider-1.jpg",
          revision: "9611448d0a85493ee21c5317323cb601",
        },
        {
          url: "/slider/slider-2.jpg",
          revision: "fe98a6e4032332b05d52aa1254f085a7",
        },
        {
          url: "/slider/slider-3.jpg",
          revision: "06cef52491c3b8682d15596e784362bb",
        },
        { url: "/sw.js", revision: "3babca1d969f2ec8e3f712ae338713de" },
        {
          url: "/team/team-1.jpg",
          revision: "e318a12728d39d01c926be7fbbcd6876",
        },
        {
          url: "/team/team-2.jpg",
          revision: "ba945720d060272d028634a8729b7d2b",
        },
        {
          url: "/team/team-3.jpg",
          revision: "dfa429c7e964aa5a8ea01c3959710529",
        },
        {
          url: "/team/team-4.jpg",
          revision: "490ae645f676543ef728fc2548a6bd3f",
        },
        {
          url: "/team/team-5.jpg",
          revision: "a345363d59da88084c7fd6de76cc978c",
        },
        {
          url: "/team/team-6.jpg",
          revision: "39e8a23ea2ae4bc88316d1ddad73132c",
        },
      ],
      { ignoreURLParametersMatching: [] }
    ),
    e.cleanupOutdatedCaches(),
    e.registerRoute(
      "/",
      new e.NetworkFirst({
        cacheName: "start-url",
        plugins: [
          {
            cacheWillUpdate: async ({
              request: e,
              response: s,
              event: a,
              state: c,
            }) =>
              s && "opaqueredirect" === s.type
                ? new Response(s.body, {
                    status: 200,
                    statusText: "OK",
                    headers: s.headers,
                  })
                : s,
          },
          { handlerDidError: async ({ request: e }) => self.fallback(e) },
        ],
      }),
      "GET"
    ),
    e.registerRoute(
      /^https:\/\/fonts\.(?:gstatic)\.com\/.*/i,
      new e.CacheFirst({
        cacheName: "google-fonts-webfonts",
        plugins: [
          new e.ExpirationPlugin({ maxEntries: 4, maxAgeSeconds: 31536e3 }),
          { handlerDidError: async ({ request: e }) => self.fallback(e) },
        ],
      }),
      "GET"
    ),
    e.registerRoute(
      /^https:\/\/fonts\.(?:googleapis)\.com\/.*/i,
      new e.StaleWhileRevalidate({
        cacheName: "google-fonts-stylesheets",
        plugins: [
          new e.ExpirationPlugin({ maxEntries: 4, maxAgeSeconds: 604800 }),
          { handlerDidError: async ({ request: e }) => self.fallback(e) },
        ],
      }),
      "GET"
    ),
    e.registerRoute(
      /\.(?:eot|otf|ttc|ttf|woff|woff2|font.css)$/i,
      new e.StaleWhileRevalidate({
        cacheName: "static-font-assets",
        plugins: [
          new e.ExpirationPlugin({ maxEntries: 4, maxAgeSeconds: 604800 }),
          { handlerDidError: async ({ request: e }) => self.fallback(e) },
        ],
      }),
      "GET"
    ),
    e.registerRoute(
      /\.(?:jpg|jpeg|gif|png|svg|ico|webp)$/i,
      new e.StaleWhileRevalidate({
        cacheName: "static-image-assets",
        plugins: [
          new e.ExpirationPlugin({ maxEntries: 64, maxAgeSeconds: 86400 }),
          { handlerDidError: async ({ request: e }) => self.fallback(e) },
        ],
      }),
      "GET"
    ),
    e.registerRoute(
      /\/_next\/image\?url=.+$/i,
      new e.StaleWhileRevalidate({
        cacheName: "next-image",
        plugins: [
          new e.ExpirationPlugin({ maxEntries: 64, maxAgeSeconds: 86400 }),
          { handlerDidError: async ({ request: e }) => self.fallback(e) },
        ],
      }),
      "GET"
    ),
    e.registerRoute(
      /\.(?:mp3|wav|ogg)$/i,
      new e.CacheFirst({
        cacheName: "static-audio-assets",
        plugins: [
          new e.RangeRequestsPlugin(),
          new e.ExpirationPlugin({ maxEntries: 32, maxAgeSeconds: 86400 }),
          { handlerDidError: async ({ request: e }) => self.fallback(e) },
        ],
      }),
      "GET"
    ),
    e.registerRoute(
      /\.(?:mp4)$/i,
      new e.CacheFirst({
        cacheName: "static-video-assets",
        plugins: [
          new e.RangeRequestsPlugin(),
          new e.ExpirationPlugin({ maxEntries: 32, maxAgeSeconds: 86400 }),
          { handlerDidError: async ({ request: e }) => self.fallback(e) },
        ],
      }),
      "GET"
    ),
    e.registerRoute(
      /\.(?:js)$/i,
      new e.StaleWhileRevalidate({
        cacheName: "static-js-assets",
        plugins: [
          new e.ExpirationPlugin({ maxEntries: 32, maxAgeSeconds: 86400 }),
          { handlerDidError: async ({ request: e }) => self.fallback(e) },
        ],
      }),
      "GET"
    ),
    e.registerRoute(
      /\.(?:css|less)$/i,
      new e.StaleWhileRevalidate({
        cacheName: "static-style-assets",
        plugins: [
          new e.ExpirationPlugin({ maxEntries: 32, maxAgeSeconds: 86400 }),
          { handlerDidError: async ({ request: e }) => self.fallback(e) },
        ],
      }),
      "GET"
    ),
    e.registerRoute(
      /\/_next\/data\/.+\/.+\.json$/i,
      new e.StaleWhileRevalidate({
        cacheName: "next-data",
        plugins: [
          new e.ExpirationPlugin({ maxEntries: 32, maxAgeSeconds: 86400 }),
          { handlerDidError: async ({ request: e }) => self.fallback(e) },
        ],
      }),
      "GET"
    ),
    e.registerRoute(
      /\.(?:json|xml|csv)$/i,
      new e.NetworkFirst({
        cacheName: "static-data-assets",
        plugins: [
          new e.ExpirationPlugin({ maxEntries: 32, maxAgeSeconds: 86400 }),
          { handlerDidError: async ({ request: e }) => self.fallback(e) },
        ],
      }),
      "GET"
    ),
    e.registerRoute(
      ({ url: e }) => {
        if (!(self.origin === e.origin)) return !1;
        const s = e.pathname;
        return !s.startsWith("/api/auth/") && !!s.startsWith("/api/");
      },
      new e.NetworkFirst({
        cacheName: "apis",
        networkTimeoutSeconds: 10,
        plugins: [
          new e.ExpirationPlugin({ maxEntries: 16, maxAgeSeconds: 86400 }),
          { handlerDidError: async ({ request: e }) => self.fallback(e) },
        ],
      }),
      "GET"
    ),
    e.registerRoute(
      ({ url: e }) => {
        if (!(self.origin === e.origin)) return !1;
        return !e.pathname.startsWith("/api/");
      },
      new e.NetworkFirst({
        cacheName: "others",
        networkTimeoutSeconds: 10,
        plugins: [
          new e.ExpirationPlugin({ maxEntries: 32, maxAgeSeconds: 86400 }),
          { handlerDidError: async ({ request: e }) => self.fallback(e) },
        ],
      }),
      "GET"
    ),
    e.registerRoute(
      ({ url: e }) => !(self.origin === e.origin),
      new e.NetworkFirst({
        cacheName: "cross-origin",
        networkTimeoutSeconds: 10,
        plugins: [
          new e.ExpirationPlugin({ maxEntries: 32, maxAgeSeconds: 3600 }),
          { handlerDidError: async ({ request: e }) => self.fallback(e) },
        ],
      }),
      "GET"
    );
});
